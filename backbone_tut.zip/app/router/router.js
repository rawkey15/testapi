define(function (require) {
    var Mylist = require ('listview');
    var MenuView = require ('menuview');

    var Router = Backbone.Router.extend({
        routes: {
            'list/:id': 'selectList',
            '': 'default'
        },
        selectList: function (id) {
            var listview = new Mylist({ listid: id });
            this.$el.html(listview.el);
        },
        default: function () {
            var menu = new MenuView();
            this.$el.html(menu.el);
        },
        initialize: function (options) {
            console.log(options)
            this.$el = options.el;
        }
    });

    return Router;
});