var ListModel = Backbone.Model.extend({
    initialize: function (options) {
        this.getList(options.api);
    },
    defaults: {
        title: "My list"
    },
    getList: function (url) {
        this.fetch({ url: url });
    },
    parse: function (obj, options) {
        this.set({ "list": obj });
    }
});

module.exports = ListModel;