var list1 = new List({api: '../list.1.json'});
var list2 = new List({api: '../list.2.json'});

var ListCollection = Backbone.Collection.extend();

module.exports = new ListCollection( [list1, list2]);