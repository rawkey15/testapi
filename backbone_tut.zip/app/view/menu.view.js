define(function (require) {
var MenuView = Backbone.View.extend({
    template: Handlebars.compile($("#route_list").html()),
    initialize: function (options) {
        this.render();
    },
    render: function () {
        this.$el.html(this.template());
    }
});
return MenuView;
});