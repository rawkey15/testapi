define(function (require) {
var MylistView = Backbone.View.extend({
    template: Handlebars.compile($("#list_view").html()),
    initialize: function (options) {
        this.render(options.listid);
    },
    events: {},
    render: function (id) {
        var self = this;
        if (id) {
            var list;
            _.each(listCollection.toJSON(), function (obj) {
                if (obj.list && obj.list.id == id) {
                    list = obj;
                }
            });
            self.$el.html(self.template(list));
        }
    }
});

return MylistView;
});