
require.config({
    paths: {
        'router': './app/router/router',
        'listview': './app/view/list.view',
        'menuview' : './app/view/menu.view'
    }
});


$(document).ready(function () {
    var Router = require("router");
    new Router({ el: $('#my_view') });
    Backbone.history.start();
});