    var Mylist = require ('../view/list.view');
    var MenuView = require ('../view/menu.view');

    var Router = Backbone.Router.extend({
        routes: {
            'list/:id': 'selectList',
            '': 'default'
        },
        selectList: function (id) {
            var listview = new Mylist({ listid: id });
            this.$el.html(listview.el);
        },
        default: function () {
            var menu = new MenuView();
            this.$el.html(menu.el);
        },
        initialize: function (options) {
            console.log(options)
            this.$el = options.el;
        }
    });

    module.exports = Router;
