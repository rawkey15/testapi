var Router = require('./router/router');

$(document).ready(function() {
  var router = new Router({
    el: $('#my_view')
  });
  Backbone.history.start();
});