var MenuView = Backbone.View.extend({
    template: require('../templates/tpl/menu.hbs'),
    initialize: function (options) {
        this.render();
    },
    render: function () {
        this.$el.html(this.template());
    }
});
module.exports = MenuView;