var MylistView = Backbone.View.extend({
    template: require('../templates/tpl/list.hbs'),
    initialize: function (options) {
        this.render(options.listid);
    },
    events: {},
    render: function (id) {
        var self = this;
        if (id) {
            var list;
            _.each(listCollection.toJSON(), function (obj) {
                if (obj.list && obj.list.id == id) {
                    list = obj;
                }
            });
            self.$el.html(self.template(list));
        }
    }
});

module.exports = MylistView;
