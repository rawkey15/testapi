const path = require('path');
const HandlebarsPrecompiler = require('webpack-handlebars-precompiler');
const webpack = require('webpack');
var os = require('os');
const UglifyJsPlugin = require('uglifyjs-3-webpack-plugin');

module.exports = {
  entry: {
    app: "./src/app/main.js"
  },
  output: {
    filename: "app.js",
    path: path.resolve(__dirname, './src/build')
  },
  devtool: 'hidden-source-map',
  module: {
    rules: [
      {
        test: /\.hbs$/,
        exclude: /node_modules/,
        use: [{
          loader: "handlebars-loader",
          options: { helperDirs: path.resolve(__dirname, "./src/app/templates/helpers") }
        }]

      }

    ]
  },
  plugins: [
    new webpack.SourceMapDevToolPlugin({
      filename: '[file].map',
      append: `\n//# sourceMappingURL=${path}[url]`
    }),
    //new UglifyJsPlugin({test: /\.js($|\?)/i})
  ]
};

